class AddPictureToBooks < ActiveRecord::Migration[5.1]
  def change
    add_column :books, :picture, :string
  end

  def show_image
    @book = Book.find(params[:id])
    send_data @book.picture, :type => 'image/jpeg', :disposition => 'inline'
  end
end
